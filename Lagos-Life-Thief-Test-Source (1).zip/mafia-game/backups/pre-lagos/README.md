# Who Be Thief? — Mafia Game

A playable, original 3D social-deduction browser prototype with a full-viewport game interface, irregular cutaway environments, nine bots, and five stages.

## Run locally

Requires Node.js 20 or newer. There are no third-party runtime or build dependencies.

```sh
npm ci
npm run dev
```

Open http://localhost:3000. To test the production output:

```sh
npm run build
npm run preview
```

## Deployment

`vercel.json` builds with `npm run build` and publishes `dist/` as a static site. No backend or environment secrets are required. A connected Vercel project may deploy commits automatically.

## Current version

- Entry screen: email profile or guest play. Email is unverified and held only in session memory; no account is created and nothing is sent to a server.
- Full-screen gameplay; instructions, information, credits, map, and round details are inside menus.
- Irregular room footprints, recessed corners, bent corridor loops, asymmetrical furniture clusters, cargo stacks, scuffs, papers, and loose cables.
- Roles are assigned randomly each round (one thief among ten actors; the player has a 10% thief chance). No role chooser.
- Five tasks are attached to existing equipment, not separate kiosks. Tap a yellow-marked machine in your current room to walk up and open its minigame; Use appears only when you are close enough. Completed tasks stop offering Use unless power must be restored.
- Opaque roofs cover every room except your current room. Characters and bodies are not rendered across room boundaries; witness checks and reports use the same room and line-of-sight rules.
- Tasks, sabotage, non-graphic eliminations, body reports, meetings, and votes.
- Meetings have a visible **30-second** discussion/voting countdown. Votes can be changed until expiry. A tied top vote gets **one additional 10-second** tiebreaker. If still tied, nobody is ejected. Missing player votes count as skip; a majority skip does not extend the meeting. Gameplay and the round timer stay paused.
- Stage unlocks are saved locally when browser storage is available.

## Controls

Click/tap open ground or use WASD/arrows to walk. Tap a marked machine to walk up and interact. E: use a nearby machine. R: report. K: eliminate as thief. Q: sabotage. G: map. M: emergency meeting. P/Escape: pause. Touch buttons are provided.

## Scope

This is a **solo prototype with scripted bot discussions**, not an online multiplayer game. Verified sign-in, live chat, multiplayer rooms, sound, and cinematic cutscenes are not connected. Stages use rotated/reflected variants of the irregular footprint. WebGL and hardware acceleration are required.

## Source layout

- `index.html`: interface and styles, with an embedded menu backdrop.
- `game.js`: original gameplay, rendering, irregular layouts, and meeting timers.
- `assets.js`: converted render meshes.
- `assets/manifest.json`: model provenance, license details, and source links.
- `licenses/`: Kenney CC0 and Biomes MIT notices, plus reference credits.
- `scripts/`: dependency-free static build and local preview server.

## Asset credits

Selected models from [Kenney Space Station Kit](https://kenney.nl/assets/space-station-kit), under CC0, and one cargo-crate model from [Biomes](https://github.com/ill-inc/biomes-game), under its repository MIT license. Preserve the notices in `licenses/` when distributing the game. The converted geometry is included; the manifest links to original source models. Supplied/Pinterest artwork was inspiration only and is not included. No separately credited Biomes music or sounds are used.

## Uploaded replacement version and rollback

The active `game.js` is based on the user-uploaded replacement. It introduces five distinct station minigames: circuit breakers, dual-frequency tuning, docket verification, calibration sequence, and cargo scanning.

Fixes applied: malformed `\vert{}\vert{}` logical-OR token replaced with `||`; initial player spawn moved to the clear aisle because the uploaded table layout blocked the former spawn; sliders given 44px touch hit areas and calibration labels kept at 14px.

`backups/game.previous.js` is the byte-for-byte former working version. `backups/game.uploaded-original.js` is the untouched upload, retained for comparison (it contains the original syntax error). `backups/version-record.json` records hashes and repairs.

To revert:

```sh
npm run revert
npm run build
```

The revert command also saves the current file as `backups/game.before-restore.js`. To return to that version, copy it back to `game.js` and rebuild.

## Interaction update backup

`backups/game.before-interactions.js` and `backups/index.before-interactions.html` preserve the version immediately before machine interaction, random role, and roof updates. The original rollback files are also retained.
