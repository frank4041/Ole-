import { copyFile } from 'node:fs/promises';
import { fileURLToPath } from 'node:url';
const path = name => fileURLToPath(new URL('../' + name, import.meta.url));
await copyFile(path('game.js'), path('backups/game.before-restore.js'));
await copyFile(path('backups/game.previous.js'), path('game.js'));
console.log('Restored the former working game.js. Current version saved as backups/game.before-restore.js.');
console.log('Run npm run build to rebuild deployment files.');
